# AI Crowd Management System

Fully autonomous crowd surveillance platform using computer vision, real-time density analysis, VIP face recognition, and zero-intervention alert dispatch.

---

## Project Structure

```
crowd_management/
├── frontend/
│   └── index.html              # Complete UI — works standalone or served by backend
├── backend/
│   ├── main.py                 # FastAPI app entry point
│   ├── websocket_server.py     # WebSocket server — streams data to frontend
│   ├── models/
│   │   ├── crowd_detector.py   # YOLO-based people counting
│   │   ├── vip_recognizer.py   # InsightFace VIP face recognition
│   │   └── flow_analyzer.py    # Crowd direction + bottleneck detection
│   ├── routes/
│   │   ├── alerts.py           # Alert history API endpoints
│   │   └── dispatch.py         # Message dispatch API (SMS/WhatsApp/Radio)
│   └── utils/
│       ├── camera.py           # RTSP camera stream manager
│       ├── zones.py            # Zone definitions and threshold logic
│       └── logger.py           # Structured logging
├── config/
│   ├── settings.py             # All configuration (thresholds, credentials)
│   ├── zones.json              # Venue zone definitions
│   └── vip_database.json       # Registered VIP face embeddings metadata
├── scripts/
│   ├── enroll_vip.py           # Script to register new VIP faces into DB
│   ├── test_cameras.py         # Test all camera RTSP streams
│   └── run_dev.sh              # Start full dev environment
├── docs/
│   └── architecture.md         # Full system architecture notes
├── requirements.txt
└── .env.example
```

---

## Quick Start

### 1. Open the frontend (no backend needed for prototype)
```bash
open frontend/index.html
```

### 2. Run the full backend (real camera + AI pipeline)
```bash
# Install dependencies
pip install -r requirements.txt

# Copy and fill in your credentials
cp .env.example .env

# Start the backend
python backend/main.py
```

Then open `frontend/index.html` and it will auto-connect to the WebSocket on `ws://localhost:8765`.

---

## Requirements
- Python 3.9+
- OpenCV-compatible IP cameras (RTSP streams)
- Twilio account (for SMS/WhatsApp dispatch)
- GPU recommended for real-time YOLO inference

---

## Key Integration Points

| File | What to configure |
|------|-------------------|
| `config/zones.json` | Add your venue's zones, capacities, camera assignments |
| `config/vip_database.json` | Add VIP names, roles, image paths |
| `.env` | Camera IPs, Twilio keys, alert thresholds |
| `scripts/enroll_vip.py` | Run this to register face embeddings for new VIPs |
