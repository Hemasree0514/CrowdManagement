# System Architecture

## Data flow (production)

```
IP Cameras (RTSP)
       │
       ▼
CameraManager        ← background threads, one per camera
(utils/camera.py)
       │  BGR frames
       ▼
┌──────────────────────────────────────────────┐
│           AI Pipeline Loop                   │
│         (websocket_server.py)                │
│                                              │
│  CrowdDetector   → people count per zone     │
│  VipRecognizer   → face match + confidence   │
│  FlowAnalyzer    → movement + anomaly type   │
└──────────────────────────────────────────────┘
       │  threshold check
       ▼
DecisionEngine
(threshold logic inline in websocket_server.py)
       │
       ├── Critical/Warning → dispatch SMS + Radio
       ├── VIP match        → dispatch App + SMS (confidential)
       ├── Bottleneck       → dispatch SMS
       └── Panic flow       → dispatch SMS + Medical team
       │
       ▼
dispatch_alert()          ← Twilio SMS / WhatsApp / App / Radio
(routes/dispatch.py)
       │
       ▼
WebSocket broadcast → all connected browser clients
       │
       ▼
frontend/index.html   ← updates UI in real time (no page reload)
```

## Real-time latency budget

| Stage | Target |
|-------|--------|
| Camera frame capture | < 50 ms |
| YOLO inference (YOLOv8s, GPU) | 30–80 ms |
| Face recognition (InsightFace) | 20–50 ms |
| Optical flow | 10–20 ms |
| Alert evaluation + dispatch | < 30 ms |
| WebSocket broadcast | < 10 ms |
| **Total: frame → alert on screen** | **< 200 ms** |

## Scaling for large events

For venues with 10+ cameras and 10,000+ crowd:
- Run YOLO on a dedicated GPU server (NVIDIA T4 or better)
- Use RTSP proxy (e.g., MediaMTX) to relay streams without latency
- Move WebSocket broadcast to Redis pub/sub for multi-server setups
- Use PostgreSQL instead of SQLite for the alert log
