"""
config/settings.py
Central configuration — reads from .env file.
All thresholds, credentials, and paths are defined here.
"""
from pydantic_settings import BaseSettings
from pydantic import Field
from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    # ── Server ────────────────────────────────────────────────────
    host:             str = "0.0.0.0"
    port:             int = 8000
    websocket_port:   int = 8765
    debug:            bool = True

    # ── Camera streams (RTSP URLs) ────────────────────────────────
    cam_01: str = ""
    cam_02: str = ""
    cam_03: str = ""
    cam_04: str = ""
    cam_05: str = ""
    cam_06: str = ""

    # ── Crowd thresholds ──────────────────────────────────────────
    density_warning_pct:  float = 0.60
    density_critical_pct: float = 0.85

    # ── Twilio SMS/WhatsApp ───────────────────────────────────────
    twilio_account_sid:    str = ""
    twilio_auth_token:     str = ""
    twilio_from_number:    str = ""
    twilio_whatsapp_from:  str = ""

    # ── Alert recipient phones ────────────────────────────────────
    unit_alpha_phone:      str = ""
    unit_beta_phone:       str = ""
    unit_gamma_phone:      str = ""
    unit_delta_phone:      str = ""
    unit_echo_phone:       str = ""
    unit_foxtrot_phone:    str = ""
    command_centre_phone:  str = ""
    protocol_officer_phone:str = ""
    medical_team_phone:    str = ""

    # ── Face recognition ──────────────────────────────────────────
    vip_confidence_threshold: float = 0.92
    face_model:               str   = "buffalo_l"
    vip_images_dir:           str   = "config/vip_faces"

    # ── Database ──────────────────────────────────────────────────
    database_url: str = "sqlite+aiosqlite:///./crowd_management.db"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    # ── Derived helpers ───────────────────────────────────────────
    @property
    def zones(self) -> list:
        with open(BASE_DIR / "config" / "zones.json") as f:
            return json.load(f)

    @property
    def vip_db(self) -> list:
        with open(BASE_DIR / "config" / "vip_database.json") as f:
            return json.load(f)

    def phone_for_unit(self, unit_name: str) -> str:
        """Map security unit name → phone number from env."""
        mapping = {
            "Unit Alpha":   self.unit_alpha_phone,
            "Unit Beta":    self.unit_beta_phone,
            "Unit Gamma":   self.unit_gamma_phone,
            "Unit Delta":   self.unit_delta_phone,
            "Unit Echo":    self.unit_echo_phone,
            "Unit Foxtrot": self.unit_foxtrot_phone,
            "Command Centre":       self.command_centre_phone,
            "Protocol Officer":     self.protocol_officer_phone,
            "Medical team":         self.medical_team_phone,
        }
        return mapping.get(unit_name, "")


settings = Settings()
